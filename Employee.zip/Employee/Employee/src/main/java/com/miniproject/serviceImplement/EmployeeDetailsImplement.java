package com.miniproject.serviceImplement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miniproject.entity.EmployeeDetails;
import com.miniproject.repository.EmployeeDetailsRepo;
import com.miniproject.service.EmployeeDetailsInterface;
@Service
public class EmployeeDetailsImplement  implements EmployeeDetailsInterface{
	
	@Autowired
	EmployeeDetailsRepo  repo;
     public void saveToDb(EmployeeDetails employee) {
    	 repo.save(employee);
     }
}
