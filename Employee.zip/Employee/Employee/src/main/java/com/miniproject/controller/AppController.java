package com.miniproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.miniproject.entity.EmployeeDetails;
import com.miniproject.repository.EmployeeDetailsRepo;
import com.miniproject.serviceImplement.EmployeeDetailsImplement;

@RestController
public class AppController {
	@Autowired
	EmployeeDetailsImplement obj;
	@Autowired
	EmployeeDetailsRepo repo;

	@PostMapping("/saveEmployeeDetails")
	public EmployeeDetails saveDetails(@RequestBody EmployeeDetails employee) {
		obj.saveToDb(employee);
		return repo.findByUserId(employee.getUserId());

	}
	@PutMapping("/{userId}/{fname}")
	public EmployeeDetails updateDetails(@PathVariable int userId,@PathVariable String fname) {
		EmployeeDetails employee=repo.findByUserId(userId);
		employee.setFirstName(fname);
		obj.saveToDb(employee);
		return repo.findByUserId(employee.getUserId());
	}
	@DeleteMapping("/delete")
	public String deleteRecord(@RequestParam int userId) {
		EmployeeDetails employee=repo.findByUserId(userId);
		repo.delete(employee);
		return"user details deleted successfully";
	}
	@GetMapping("/getAllEmployeeDetails")
	public List<EmployeeDetails> getDetails(){
		return repo.findAll();
	}


}
