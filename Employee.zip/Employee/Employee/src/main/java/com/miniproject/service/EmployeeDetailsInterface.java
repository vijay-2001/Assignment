package com.miniproject.service;

import com.miniproject.entity.EmployeeDetails;

public interface EmployeeDetailsInterface {
	public void saveToDb(EmployeeDetails employee);
}
